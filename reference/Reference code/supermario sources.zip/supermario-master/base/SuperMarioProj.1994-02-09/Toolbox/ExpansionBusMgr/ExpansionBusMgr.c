/*
	File:		ExpansionBusMgr.c

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	© 1993 by Apple Computer, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	11/11/93	fau		first checked in

*/

/*
 * File:		ExpansionMgrInit.c
 *
 * Contains:	Expansion Mgr Initialization
 *
 * Written by:	Al Kossow
 *
 * Copyright:	© 1993 by Apple Computer, Inc., all rights reserved.
 *
 * Change History (most recent first):
 *
 * <1>			10/20/93	aek		Created
 *
 * The device tree, and all connected buses and devices and registered
 * here.
 *
 */
 
InitExpansionMgr()
{
}

InitHWConfigMgr()
{

}