/*
	File:		FileTransfersPriv.h

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	© 1990 by Apple Computer, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 3/14/90	BBH		first checked in

	To Do:
*/

#ifndef	__FileTransfersPriv__
#define	__FileTransfersPriv__

extern pascal FTErr FTCleanup(FTHandle hFT, Boolean now);

#endif	__FileTransfersPriv__